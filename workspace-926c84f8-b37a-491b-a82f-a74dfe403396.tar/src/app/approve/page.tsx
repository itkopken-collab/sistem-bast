'use client'

import { useEffect, useState } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { CheckCircle, XCircle, Loader2, AlertCircle } from 'lucide-react'

export default function ApprovalPage() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [status, setStatus] = useState<'success' | 'error' | null>(null)
  const [message, setMessage] = useState('')

  useEffect(() => {
    async function processApproval() {
      const bastNumber = searchParams.get('bastNumber')
      const role = searchParams.get('role')
      const action = searchParams.get('action')

      if (!bastNumber || !role || !action) {
        setStatus('error')
        setMessage('Parameter tidak lengkap. Harap gunakan tombol dari email untuk approval.')
        setLoading(false)
        return
      }

      try {
        const response = await fetch('/api/bast/approve', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            bastNumber,
            role,
            action
          })
        })

        if (response.ok) {
          const result = await response.json()
          setStatus('success')
          setMessage(result.message || 'Approval berhasil diproses')
        } else {
          const error = await response.json()
          setStatus('error')
          setMessage(error.error || 'Gagal memproses approval')
        }
      } catch (error) {
        setStatus('error')
        setMessage('Terjadi kesalahan saat memproses approval. Silakan coba lagi.')
      } finally {
        setLoading(false)
      }
    }

    processApproval()
  }, [searchParams])

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900 flex items-center justify-center p-4">
      <Card className="max-w-md w-full">
        <CardHeader>
          <CardTitle className="text-2xl text-center">
            {loading ? 'Memproses...' : 'Status Approval'}
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-6">
          {loading ? (
            <div className="flex flex-col items-center gap-4">
              <Loader2 className="w-16 h-16 text-orange-600 animate-spin" />
              <p className="text-slate-600 dark:text-slate-400">
                Sedang memproses approval BAST...
              </p>
            </div>
          ) : status === 'success' ? (
            <div className="space-y-4">
              <div className="flex justify-center">
                <CheckCircle className="w-20 h-20 text-green-600" />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-semibold text-green-700 dark:text-green-400">
                  Berhasil!
                </h3>
                <p className="text-slate-600 dark:text-slate-400">{message}</p>
              </div>
              <div className="pt-4 space-y-2">
                <Button
                  onClick={() => router.push('/')}
                  className="w-full bg-orange-600 hover:bg-orange-700"
                >
                  Kembali ke Halaman Utama
                </Button>
                <Button
                  variant="outline"
                  onClick={() => router.push(`/?track=${searchParams.get('bastNumber')}`)}
                  className="w-full"
                >
                  Lacak Status BAST
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex justify-center">
                <XCircle className="w-20 h-20 text-red-600" />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-semibold text-red-700 dark:text-red-400">
                  Gagal
                </h3>
                <p className="text-slate-600 dark:text-slate-400">{message}</p>
              </div>
              <div className="pt-4">
                <Button
                  onClick={() => router.push('/')}
                  className="w-full"
                  variant="outline"
                >
                  Kembali ke Halaman Utama
                </Button>
              </div>
            </div>
          )}

          <div className="pt-6 border-t">
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Halaman ini digunakan untuk memproses approval dari email yang dikirim oleh sistem.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
