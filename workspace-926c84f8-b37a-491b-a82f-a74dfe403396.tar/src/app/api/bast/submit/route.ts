import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { writeFile, mkdir } from 'fs/promises'
import { join } from 'path'
import { sendBASTToITSupport } from '@/lib/email-service'

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData()

    const submitterName = formData.get('submitterName') as string
    const companyName = formData.get('companyName') as string
    const companyAddress = formData.get('companyAddress') as string
    const installationType = formData.get('installationType') as string
    const storeName = formData.get('storeName') as string
    const workAddress = formData.get('workAddress') as string
    const picName = formData.get('picName') as string
    const poNumber = formData.get('poNumber') as string
    const completionDate = formData.get('completionDate') as string
    const vendorEmail = formData.get('vendorEmail') as string
    const additionalFields = formData.get('additionalFields') as string

    // Handle file uploads
    const uploadedPhotos: string[] = []
    let fileIndex = 0

    while (formData.get(`photo${fileIndex}`)) {
      const file = formData.get(`photo${fileIndex}`) as File
      if (file) {
        const bytes = await file.arrayBuffer()
        const buffer = Buffer.from(bytes)

        // Create uploads directory if it doesn't exist
        const uploadsDir = join(process.cwd(), 'public', 'uploads')
        await mkdir(uploadsDir, { recursive: true })

        // Generate unique filename
        const timestamp = Date.now()
        const filename = `bast_${timestamp}_${fileIndex}.${file.name.split('.').pop()}`
        const filepath = join(uploadsDir, filename)

        await writeFile(filepath, buffer)
        uploadedPhotos.push(`/uploads/${filename}`)
      }
      fileIndex++
    }

    // Generate unique BAST number
    const timestamp = Date.now()
    const randomPart = Math.floor(Math.random() * 10000).toString().padStart(4, '0')
    const bastNumber = `BAST${timestamp}${randomPart}`

    // Create BAST record
    const bast = await db.bAST.create({
      data: {
        bastNumber,
        submitterName,
        companyName,
        companyAddress,
        installationType,
        storeName,
        workAddress,
        picName,
        poNumber,
        completionDate,
        vendorEmail,
        documentationPhotos: JSON.stringify(uploadedPhotos),
        additionalFields,
        status: 'pending'
      }
    })

    // Send email to IT Support with PDF and approval buttons
    try {
      const itSupportEmail = process.env.IT_SUPPORT_EMAIL || 'it-support@kedai-kopi.com'
      const itSupportName = process.env.IT_SUPPORT_NAME || 'IT Support'

      await sendBASTToITSupport(
        {
          bastNumber: bast.bastNumber,
          submitterName,
          companyName,
          companyAddress,
          installationType,
          storeName,
          workAddress,
          picName,
          poNumber,
          completionDate,
          vendorEmail,
          additionalFields: JSON.parse(additionalFields),
          createdAt: bast.createdAt.toISOString()
        },
        itSupportEmail,
        itSupportName
      )
    } catch (emailError) {
      console.error('Error sending email to IT Support:', emailError)
      // Continue even if email fails, but log it
    }

    return NextResponse.json({
      success: true,
      bastNumber: bast.bastNumber,
      message: 'BAST submitted successfully'
    })
  } catch (error) {
    console.error('Error submitting BAST:', error)
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to submit BAST'
      },
      { status: 500 }
    )
  }
}
