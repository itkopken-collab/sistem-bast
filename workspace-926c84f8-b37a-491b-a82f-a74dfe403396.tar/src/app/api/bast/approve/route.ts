import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { sendBASTToITManager, sendApprovalNotificationToVendor, sendRejectionNotification } from '@/lib/email-service'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { bastNumber, role, action, comment } = body

    // Validate inputs
    if (!bastNumber || !role || !action) {
      return NextResponse.json(
        { error: 'Missing required fields: bastNumber, role, action' },
        { status: 400 }
      )
    }

    if (!['it_support', 'it_manager'].includes(role)) {
      return NextResponse.json(
        { error: 'Invalid role. Must be it_support or it_manager' },
        { status: 400 }
      )
    }

    if (!['approve', 'reject'].includes(action)) {
      return NextResponse.json(
        { error: 'Invalid action. Must be approve or reject' },
        { status: 400 }
      )
    }

    // Find BAST
    const bast = await db.bAST.findUnique({
      where: { bastNumber }
    })

    if (!bast) {
      return NextResponse.json(
        { error: 'BAST not found' },
        { status: 404 }
      )
    }

    // Handle IT Support approval/reject
    if (role === 'it_support') {
      // Update BAST with IT Support decision
      const updatedBast = await db.bAST.update({
        where: { bastNumber },
        data: {
          itSupportApproval: action === 'approve' ? 'approved' : 'rejected',
          itSupportComment: comment || null,
          status: action === 'approve' ? 'it_manager_pending' : 'rejected'
        }
      })

      // Send email based on action
      try {
        const additionalFields = JSON.parse(bast.additionalFields || '[]')

        if (action === 'approve') {
          // Send email to IT Manager with PDF and approval buttons
          const itManagerEmail = process.env.IT_MANAGER_EMAIL || 'it-manager@kedai-kopi.com'
          const itManagerName = process.env.IT_MANAGER_NAME || 'IT Manager'

          await sendBASTToITManager(
            {
              bastNumber: bast.bastNumber,
              submitterName: bast.submitterName,
              companyName: bast.companyName,
              companyAddress: bast.companyAddress,
              installationType: bast.installationType,
              storeName: bast.storeName,
              workAddress: bast.workAddress,
              picName: bast.picName,
              poNumber: bast.poNumber,
              completionDate: bast.completionDate,
              vendorEmail: bast.vendorEmail,
              additionalFields,
              createdAt: bast.createdAt.toISOString()
            },
            itManagerEmail,
            itManagerName
          )
        } else {
          // Send rejection notification to vendor
          await sendRejectionNotification(
            bast.vendorEmail,
            bast.submitterName,
            bast.bastNumber,
            comment || 'BAST ditolak oleh IT Support'
          )
        }
      } catch (emailError) {
        console.error('Error sending email:', emailError)
        // Continue even if email fails, but log it
      }

      return NextResponse.json({
        success: true,
        message: `BAST ${action === 'approve' ? 'approved' : 'rejected'} by IT Support`,
        bast: {
          bastNumber: updatedBast.bastNumber,
          status: updatedBast.status,
          itSupportApproval: updatedBast.itSupportApproval
        }
      })
    }

    // Handle IT Manager approval/reject
    if (role === 'it_manager') {
      // Check if IT Support has approved first
      if (bast.itSupportApproval !== 'approved') {
        return NextResponse.json(
          { error: 'Cannot approve/reject. IT Support has not approved this BAST yet.' },
          { status: 400 }
        )
      }

      // Update BAST with IT Manager decision
      const updatedBast = await db.bAST.update({
        where: { bastNumber },
        data: {
          itManagerApproval: action === 'approve' ? 'approved' : 'rejected',
          itManagerComment: comment || null,
          status: action === 'approve' ? 'approved' : 'rejected'
        }
      })

      // Send email based on action
      try {
        const additionalFields = JSON.parse(bast.additionalFields || '[]')

        // Send notification to vendor
        await sendApprovalNotificationToVendor(
          {
            bastNumber: bast.bastNumber,
            submitterName: bast.submitterName,
            companyName: bast.companyName,
            companyAddress: bast.companyAddress,
            installationType: bast.installationType,
            storeName: bast.storeName,
            workAddress: bast.workAddress,
            picName: bast.picName,
            poNumber: bast.poNumber,
            completionDate: bast.completionDate,
            vendorEmail: bast.vendorEmail,
            additionalFields,
            createdAt: bast.createdAt.toISOString()
          },
          action === 'approve' ? 'approved' : 'rejected'
        )

        // If rejected, also notify IT Support
        if (action === 'reject') {
          const itSupportEmail = process.env.IT_SUPPORT_EMAIL || 'it-support@kedai-kopi.com'
          await sendRejectionNotification(
            itSupportEmail,
            'IT Support',
            bast.bastNumber,
            comment || 'BAST ditolak oleh IT Manager'
          )
        }
      } catch (emailError) {
        console.error('Error sending email:', emailError)
        // Continue even if email fails, but log it
      }

      return NextResponse.json({
        success: true,
        message: `BAST ${action === 'approve' ? 'approved' : 'rejected'} by IT Manager`,
        bast: {
          bastNumber: updatedBast.bastNumber,
          status: updatedBast.status,
          itSupportApproval: updatedBast.itSupportApproval,
          itManagerApproval: updatedBast.itManagerApproval
        }
      })
    }

    return NextResponse.json(
      { error: 'Invalid request' },
      { status: 400 }
    )
  } catch (error) {
    console.error('Error processing BAST approval:', error)
    return NextResponse.json(
      { error: 'Failed to process approval' },
      { status: 500 }
    )
  }
}
