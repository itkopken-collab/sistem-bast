import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const bastNumber = searchParams.get('bastNumber')

    if (!bastNumber) {
      return NextResponse.json(
        { error: 'BAST number is required' },
        { status: 400 }
      )
    }

    const bast = await db.bAST.findUnique({
      where: {
        bastNumber: bastNumber
      }
    })

    if (!bast) {
      return NextResponse.json(
        { error: 'BAST not found' },
        { status: 404 }
      )
    }

    // Parse JSON fields
    const documentationPhotos = JSON.parse(bast.documentationPhotos || '[]')
    const additionalFields = JSON.parse(bast.additionalFields || '[]')

    return NextResponse.json({
      bastNumber: bast.bastNumber,
      submitterName: bast.submitterName,
      companyName: bast.companyName,
      companyAddress: bast.companyAddress,
      installationType: bast.installationType,
      storeName: bast.storeName,
      workAddress: bast.workAddress,
      picName: bast.picName,
      poNumber: bast.poNumber,
      completionDate: bast.completionDate,
      vendorEmail: bast.vendorEmail,
      documentationPhotos,
      additionalFields,
      status: bast.status,
      itSupportApproval: bast.itSupportApproval,
      itManagerApproval: bast.itManagerApproval,
      itSupportComment: bast.itSupportComment,
      itManagerComment: bast.itManagerComment,
      createdAt: bast.createdAt.toISOString()
    })
  } catch (error) {
    console.error('Error tracking BAST:', error)
    return NextResponse.json(
      { error: 'Failed to track BAST' },
      { status: 500 }
    )
  }
}
