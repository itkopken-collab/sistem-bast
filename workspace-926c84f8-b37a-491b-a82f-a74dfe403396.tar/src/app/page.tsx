'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Upload, CheckCircle, XCircle, Clock, FileText } from 'lucide-react'

type BASTStatus = 'pending' | 'it_support_pending' | 'it_manager_pending' | 'approved' | 'rejected'

interface BASTData {
  bastNumber: string
  submitterName: string
  companyName: string
  companyAddress: string
  installationType: string
  storeName: string
  workAddress: string
  picName: string
  poNumber: string
  completionDate: string
  vendorEmail: string
  documentationPhotos: string[]
  additionalFields: { key: string; value: string }[]
  status: BASTStatus
  itSupportApproval?: 'approved' | 'rejected'
  itManagerApproval?: 'approved' | 'rejected'
  itSupportComment?: string
  itManagerComment?: string
  createdAt: string
}

export default function BASTPage() {
  const [activeTab, setActiveTab] = useState<'submit' | 'track'>('submit')
  const [formData, setFormData] = useState({
    submitterName: '',
    companyName: '',
    companyAddress: '',
    installationType: '',
    storeName: '',
    workAddress: '',
    picName: '',
    poNumber: '',
    completionDate: '',
    vendorEmail: '',
    additionalFields: [{ key: '', value: '' }]
  })
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submittedBastNumber, setSubmittedBastNumber] = useState<string>('')
  const [trackNumber, setTrackNumber] = useState('')
  const [bastData, setBastData] = useState<BASTData | null>(null)
  const [isTracking, setIsTracking] = useState(false)

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  const handleAddField = () => {
    setFormData(prev => ({
      ...prev,
      additionalFields: [...prev.additionalFields, { key: '', value: '' }]
    }))
  }

  const handleRemoveField = (index: number) => {
    setFormData(prev => ({
      ...prev,
      additionalFields: prev.additionalFields.filter((_, i) => i !== index)
    }))
  }

  const handleFieldChange = (index: number, type: 'key' | 'value', value: string) => {
    setFormData(prev => ({
      ...prev,
      additionalFields: prev.additionalFields.map((field, i) =>
        i === index ? { ...field, [type]: value } : field
      )
    }))
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    setUploadedFiles(prev => [...prev, ...files])
  }

  const handleRemoveFile = (index: number) => {
    setUploadedFiles(prev => prev.filter((_, i) => i !== index))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const formDataToSend = new FormData()
      Object.entries(formData).forEach(([key, value]) => {
        if (key !== 'additionalFields') {
          formDataToSend.append(key, value)
        }
      })

      formDataToSend.append('additionalFields', JSON.stringify(formData.additionalFields))

      uploadedFiles.forEach((file, index) => {
        formDataToSend.append(`photo${index}`, file)
      })

      const response = await fetch('/api/bast/submit', {
        method: 'POST',
        body: formDataToSend
      })

      if (!response.ok) {
        throw new Error('Failed to submit BAST')
      }

      const result = await response.json()
      setSubmittedBastNumber(result.bastNumber)
    } catch (error) {
      console.error('Error submitting BAST:', error)
      alert('Gagal mengirim BAST. Silakan coba lagi.')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleTrack = async () => {
    if (!trackNumber.trim()) {
      alert('Masukkan No BAST')
      return
    }

    setIsTracking(true)
    try {
      const response = await fetch(`/api/bast/track?bastNumber=${encodeURIComponent(trackNumber)}`)
      if (!response.ok) {
        throw new Error('BAST not found')
      }
      const data = await response.json()
      setBastData(data)
    } catch (error) {
      console.error('Error tracking BAST:', error)
      alert('No BAST tidak ditemukan')
      setBastData(null)
    } finally {
      setIsTracking(false)
    }
  }

  const getStatusBadge = (status: BASTStatus) => {
    const statusConfig = {
      pending: { label: 'Menunggu Approval IT Support', icon: Clock, color: 'bg-yellow-100 text-yellow-800 border-yellow-300' },
      it_support_pending: { label: 'Menunggu Approval IT Support', icon: Clock, color: 'bg-yellow-100 text-yellow-800 border-yellow-300' },
      it_manager_pending: { label: 'Menunggu Approval IT Manager', icon: Clock, color: 'bg-blue-100 text-blue-800 border-blue-300' },
      approved: { label: 'Disetujui', icon: CheckCircle, color: 'bg-green-100 text-green-800 border-green-300' },
      rejected: { label: 'Ditolak', icon: XCircle, color: 'bg-red-100 text-red-800 border-red-300' }
    }

    const config = statusConfig[status]
    const Icon = config.icon

    return (
      <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg border ${config.color}`}>
        <Icon className="w-4 h-4" />
        <span className="font-medium">{config.label}</span>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      {/* Header */}
      <header className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-center gap-4">
            <FileText className="w-10 h-10 text-orange-600" />
            <div>
              <h1 className="text-3xl font-bold text-slate-900 dark:text-slate-100">
                Form BAST
              </h1>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Berita Acara Serah Terima - Sistem Approval
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 pb-32">
        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as 'submit' | 'track')} className="max-w-4xl mx-auto">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="submit">Form Pengajuan BAST</TabsTrigger>
            <TabsTrigger value="track">Lacak Status BAST</TabsTrigger>
          </TabsList>

          {/* Submit Form Tab */}
          <TabsContent value="submit">
            {submittedBastNumber ? (
              <Card className="border-green-200 dark:border-green-800">
                <CardHeader className="text-center">
                  <div className="mx-auto mb-4 w-16 h-16 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center">
                    <CheckCircle className="w-8 h-8 text-green-600 dark:text-green-400" />
                  </div>
                  <CardTitle className="text-2xl text-green-700 dark:text-green-400">
                    BAST Berhasil Disubmit!
                  </CardTitle>
                  <CardDescription className="text-base">
                    Simpan No BAST Anda untuk melacak status approval
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="bg-slate-50 dark:bg-slate-800 p-6 rounded-lg text-center">
                    <p className="text-sm text-slate-600 dark:text-slate-400 mb-2">No BAST Anda:</p>
                    <p className="text-3xl font-mono font-bold text-orange-600 dark:text-orange-400">
                      {submittedBastNumber}
                    </p>
                  </div>
                  <div className="bg-blue-50 dark:bg-blue-950 p-4 rounded-lg">
                    <p className="text-sm text-blue-800 dark:text-blue-200">
                      <strong>Langkah Selanjutnya:</strong> BAST Anda akan dikirim ke IT Support untuk review dan approval.
                      Gunakan No BAST di atas untuk melacak status approval di tab "Lacak Status BAST".
                    </p>
                  </div>
                  <Button
                    onClick={() => {
                      setSubmittedBastNumber('')
                      setFormData({
                        submitterName: '',
                        companyName: '',
                        companyAddress: '',
                        installationType: '',
                        storeName: '',
                        workAddress: '',
                        picName: '',
                        poNumber: '',
                        completionDate: '',
                        vendorEmail: '',
                        additionalFields: [{ key: '', value: '' }]
                      })
                      setUploadedFiles([])
                    }}
                    variant="outline"
                    className="w-full"
                  >
                    Submit BAST Baru
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle>Form Pengajuan BAST</CardTitle>
                  <CardDescription>
                    Lengkapi formulir di bawah ini untuk mengajukan Berita Acara Serah Terima
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    {/* Tracking Information */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100 border-b pb-2">
                        Informasi Submitter
                      </h3>
                      <div className="space-y-2">
                        <Label htmlFor="submitterName">Nama Submitter *</Label>
                        <Input
                          id="submitterName"
                          placeholder="Masukkan nama lengkap submitter"
                          value={formData.submitterName}
                          onChange={(e) => handleInputChange('submitterName', e.target.value)}
                          required
                        />
                      </div>
                    </div>

                    {/* Company Information */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100 border-b pb-2">
                        Informasi Perusahaan
                      </h3>
                      <div className="space-y-2">
                        <Label htmlFor="companyName">Nama Perusahaan *</Label>
                        <Input
                          id="companyName"
                          placeholder="Masukkan nama perusahaan vendor"
                          value={formData.companyName}
                          onChange={(e) => handleInputChange('companyName', e.target.value)}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="companyAddress">Alamat Perusahaan *</Label>
                        <Textarea
                          id="companyAddress"
                          placeholder="Masukkan alamat lengkap perusahaan"
                          value={formData.companyAddress}
                          onChange={(e) => handleInputChange('companyAddress', e.target.value)}
                          required
                          rows={3}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="installationType">Jenis Instalasi *</Label>
                        <Select
                          value={formData.installationType}
                          onValueChange={(value) => handleInputChange('installationType', value)}
                          required
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Pilih jenis instalasi" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="CCTV">Instalasi CCTV</SelectItem>
                            <SelectItem value="Store Installation">Instalasi Store</SelectItem>
                            <SelectItem value="Internet Installation">Instalasi Internet</SelectItem>
                            <SelectItem value="Other">Lainnya</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Work Information */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100 border-b pb-2">
                        Informasi Pengerjaan
                      </h3>
                      <div className="space-y-2">
                        <Label htmlFor="storeName">Nama Store *</Label>
                        <Input
                          id="storeName"
                          placeholder="Masukkan nama store"
                          value={formData.storeName}
                          onChange={(e) => handleInputChange('storeName', e.target.value)}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="workAddress">Alamat Pengerjaan *</Label>
                        <Textarea
                          id="workAddress"
                          placeholder="Masukkan alamat lengkap pengerjaan"
                          value={formData.workAddress}
                          onChange={(e) => handleInputChange('workAddress', e.target.value)}
                          required
                          rows={3}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="picName">Nama PIC IT *</Label>
                        <Input
                          id="picName"
                          placeholder="Masukkan nama PIC IT"
                          value={formData.picName}
                          onChange={(e) => handleInputChange('picName', e.target.value)}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="poNumber">Nomor PO *</Label>
                        <Input
                          id="poNumber"
                          placeholder="Masukkan nomor PO"
                          value={formData.poNumber}
                          onChange={(e) => handleInputChange('poNumber', e.target.value)}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="completionDate">Tanggal Selesai Pengerjaan *</Label>
                        <Input
                          id="completionDate"
                          type="date"
                          value={formData.completionDate}
                          onChange={(e) => handleInputChange('completionDate', e.target.value)}
                          required
                        />
                      </div>
                    </div>

                    {/* Vendor Contact */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100 border-b pb-2">
                        Kontak Vendor
                      </h3>
                      <div className="space-y-2">
                        <Label htmlFor="vendorEmail">Email Vendor *</Label>
                        <Input
                          id="vendorEmail"
                          type="email"
                          placeholder="vendor@company.com"
                          value={formData.vendorEmail}
                          onChange={(e) => handleInputChange('vendorEmail', e.target.value)}
                          required
                        />
                      </div>
                    </div>

                    {/* Documentation Photos */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100 border-b pb-2">
                        Dokumentasi Foto
                      </h3>
                      <div className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-lg p-6">
                        <div className="flex flex-col items-center justify-center gap-2">
                          <Upload className="w-10 h-10 text-slate-400" />
                          <p className="text-sm text-slate-600 dark:text-slate-400">
                            Upload foto dokumentasi pengerjaan
                          </p>
                          <Input
                            type="file"
                            accept="image/*"
                            multiple
                            onChange={handleFileUpload}
                            className="max-w-xs"
                          />
                        </div>
                      </div>
                      {uploadedFiles.length > 0 && (
                        <div className="space-y-2 max-h-48 overflow-y-auto">
                          {uploadedFiles.map((file, index) => (
                            <div
                              key={index}
                              className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800 rounded-lg"
                            >
                              <span className="text-sm truncate flex-1">{file.name}</span>
                              <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                onClick={() => handleRemoveFile(index)}
                                className="text-red-600 hover:text-red-700"
                              >
                                Hapus
                              </Button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Additional Fields */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100 border-b pb-2">
                        Informasi Tambahan
                      </h3>
                      <div className="space-y-3">
                        {formData.additionalFields.map((field, index) => (
                          <div key={index} className="flex gap-2">
                            <Input
                              placeholder="Nama field"
                              value={field.key}
                              onChange={(e) => handleFieldChange(index, 'key', e.target.value)}
                              className="flex-1"
                            />
                            <Input
                              placeholder="Nilai"
                              value={field.value}
                              onChange={(e) => handleFieldChange(index, 'value', e.target.value)}
                              className="flex-1"
                            />
                            {formData.additionalFields.length > 1 && (
                              <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                onClick={() => handleRemoveField(index)}
                                className="text-red-600 hover:text-red-700"
                              >
                                Hapus
                              </Button>
                            )}
                          </div>
                        ))}
                        <Button
                          type="button"
                          variant="outline"
                          onClick={handleAddField}
                          className="w-full"
                        >
                          + Tambah Field
                        </Button>
                      </div>
                    </div>

                    <Button
                      type="submit"
                      className="w-full bg-orange-600 hover:bg-orange-700"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? 'Mengirim...' : 'Submit BAST'}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Tracking Tab */}
          <TabsContent value="track">
            <Card>
              <CardHeader>
                <CardTitle>Lacak Status BAST</CardTitle>
                <CardDescription>
                  Masukkan No BAST untuk melihat status approval
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex gap-2">
                  <Input
                    placeholder="Masukkan No BAST"
                    value={trackNumber}
                    onChange={(e) => setTrackNumber(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleTrack()}
                    className="flex-1"
                  />
                  <Button
                    onClick={handleTrack}
                    disabled={isTracking}
                    className="bg-orange-600 hover:bg-orange-700"
                  >
                    {isTracking ? 'Mencari...' : 'Lacak'}
                  </Button>
                </div>

                {bastData && (
                  <div className="space-y-4">
                    <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <p className="text-sm text-slate-600 dark:text-slate-400">No BAST</p>
                          <p className="text-xl font-mono font-bold text-orange-600 dark:text-orange-400">
                            {bastData.bastNumber}
                          </p>
                        </div>
                        {getStatusBadge(bastData.status)}
                      </div>
                    </div>

                    {/* Approval Workflow */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100 border-b pb-2">
                        Workflow Approval
                      </h3>
                      <div className="space-y-3">
                        {/* IT Support Approval */}
                        <div className="p-4 rounded-lg border-2 bg-slate-50 dark:bg-slate-800">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <p className="font-semibold text-slate-900 dark:text-slate-100">IT Support</p>
                              <p className="text-sm text-slate-600 dark:text-slate-400">Review pertama</p>
                            </div>
                            {bastData.itSupportApproval ? (
                              bastData.itSupportApproval === 'approved' ? (
                                <div className="flex items-center gap-1 text-green-600">
                                  <CheckCircle className="w-5 h-5" />
                                  <span className="font-medium">Disetujui</span>
                                </div>
                              ) : (
                                <div className="flex items-center gap-1 text-red-600">
                                  <XCircle className="w-5 h-5" />
                                  <span className="font-medium">Ditolak</span>
                                </div>
                              )
                            ) : (
                              <div className="flex items-center gap-1 text-yellow-600">
                                <Clock className="w-5 h-5" />
                                <span className="font-medium">Menunggu</span>
                              </div>
                            )}
                          </div>
                          {bastData.itSupportComment && (
                            <div className="mt-2 p-2 bg-white dark:bg-slate-700 rounded text-sm">
                              <p className="text-slate-600 dark:text-slate-300">
                                <strong>Catatan:</strong> {bastData.itSupportComment}
                              </p>
                            </div>
                          )}
                        </div>

                        {/* IT Manager Approval */}
                        <div className={`p-4 rounded-lg border-2 ${
                          bastData.itSupportApproval === 'approved'
                            ? 'bg-slate-50 dark:bg-slate-800'
                            : 'bg-slate-100 dark:bg-slate-900 opacity-50'
                        }`}>
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <p className="font-semibold text-slate-900 dark:text-slate-100">IT Manager</p>
                              <p className="text-sm text-slate-600 dark:text-slate-400">Approval akhir</p>
                            </div>
                            {bastData.itManagerApproval ? (
                              bastData.itManagerApproval === 'approved' ? (
                                <div className="flex items-center gap-1 text-green-600">
                                  <CheckCircle className="w-5 h-5" />
                                  <span className="font-medium">Disetujui</span>
                                </div>
                              ) : (
                                <div className="flex items-center gap-1 text-red-600">
                                  <XCircle className="w-5 h-5" />
                                  <span className="font-medium">Ditolak</span>
                                </div>
                              )
                            ) : (
                              <div className="flex items-center gap-1 text-yellow-600">
                                <Clock className="w-5 h-5" />
                                <span className="font-medium">
                                  {bastData.itSupportApproval === 'approved' ? 'Menunggu' : 'Terkunci'}
                                </span>
                              </div>
                            )}
                          </div>
                          {bastData.itManagerComment && (
                            <div className="mt-2 p-2 bg-white dark:bg-slate-700 rounded text-sm">
                              <p className="text-slate-600 dark:text-slate-300">
                                <strong>Catatan:</strong> {bastData.itManagerComment}
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* BAST Details */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100 border-b pb-2">
                        Detail BAST
                      </h3>
                      <div className="grid gap-3 text-sm">
                        <div className="flex justify-between">
                          <span className="text-slate-600 dark:text-slate-400">Nama Submitter:</span>
                          <span className="font-medium text-slate-900 dark:text-slate-100">{bastData.submitterName}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-600 dark:text-slate-400">Nama Perusahaan:</span>
                          <span className="font-medium text-slate-900 dark:text-slate-100">{bastData.companyName}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-600 dark:text-slate-400">Jenis Instalasi:</span>
                          <span className="font-medium text-slate-900 dark:text-slate-100">{bastData.installationType}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-600 dark:text-slate-400">Nama Store:</span>
                          <span className="font-medium text-slate-900 dark:text-slate-100">{bastData.storeName}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-600 dark:text-slate-400">Nomor PO:</span>
                          <span className="font-medium text-slate-900 dark:text-slate-100">{bastData.poNumber}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-600 dark:text-slate-400">Tanggal Selesai:</span>
                          <span className="font-medium text-slate-900 dark:text-slate-100">{bastData.completionDate}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="fixed bottom-0 left-0 right-0 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800">
        <div className="container mx-auto px-4 py-4">
          <p className="text-center text-sm text-slate-600 dark:text-slate-400">
            © 2025 Sistem BAST Kedai Kopi - All Rights Reserved
          </p>
        </div>
      </footer>
    </div>
  )
}
