import jsPDF from 'jspdf'

export interface BASTData {
  bastNumber: string
  submitterName: string
  companyName: string
  companyAddress: string
  installationType: string
  storeName: string
  workAddress: string
  picName: string
  poNumber: string
  completionDate: string
  vendorEmail: string
  additionalFields: { key: string; value: string }[]
  createdAt: string
}

export function generateBASTPDF(bastData: BASTData): Buffer {
  const doc = new jsPDF()
  let yPos = 20

  // Title
  doc.setFontSize(20)
  doc.setFont('helvetica', 'bold')
  doc.text('BERITA ACARA SERAH TERIMA (BAST)', 105, yPos, { align: 'center' })
  yPos += 15

  // BAST Number
  doc.setFontSize(12)
  doc.setFont('helvetica', 'normal')
  doc.text(`No BAST: ${bastData.bastNumber}`, 105, yPos, { align: 'center' })
  yPos += 20

  // Date
  const createdDate = new Date(bastData.createdAt).toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  })
  doc.text(`Tanggal: ${createdDate}`, 105, yPos, { align: 'center' })
  yPos += 25

  // Section: Informasi Perusahaan
  doc.setFontSize(14)
  doc.setFont('helvetica', 'bold')
  doc.text('I. INFORMASI PERUSAHAAN', 20, yPos)
  yPos += 10

  doc.setFontSize(11)
  doc.setFont('helvetica', 'normal')
  doc.text('Nama Perusahaan:', 20, yPos)
  doc.setFont('helvetica', 'bold')
  doc.text(bastData.companyName, 70, yPos)
  yPos += 8

  doc.setFont('helvetica', 'normal')
  doc.text('Alamat Perusahaan:', 20, yPos)
  doc.setFont('helvetica', 'bold')
  const addressLines = doc.splitTextToSize(bastData.companyAddress, 120)
  doc.text(addressLines, 70, yPos)
  yPos += addressLines.length * 7 + 5

  // Section: Informasi Submitter
  yPos += 5
  doc.setFontSize(14)
  doc.setFont('helvetica', 'bold')
  doc.text('II. INFORMASI SUBMITTER', 20, yPos)
  yPos += 10

  doc.setFontSize(11)
  doc.setFont('helvetica', 'normal')
  doc.text('Nama Submitter:', 20, yPos)
  doc.setFont('helvetica', 'bold')
  doc.text(bastData.submitterName, 70, yPos)
  yPos += 8

  doc.setFont('helvetica', 'normal')
  doc.text('Email Vendor:', 20, yPos)
  doc.setFont('helvetica', 'bold')
  doc.text(bastData.vendorEmail, 70, yPos)
  yPos += 15

  // Section: Informasi Pekerjaan
  doc.setFontSize(14)
  doc.setFont('helvetica', 'bold')
  doc.text('III. INFORMASI PEKERJAAN', 20, yPos)
  yPos += 10

  doc.setFontSize(11)
  doc.setFont('helvetica', 'normal')
  doc.text('Jenis Instalasi:', 20, yPos)
  doc.setFont('helvetica', 'bold')
  doc.text(bastData.installationType, 70, yPos)
  yPos += 8

  doc.setFont('helvetica', 'normal')
  doc.text('Nama Store:', 20, yPos)
  doc.setFont('helvetica', 'bold')
  doc.text(bastData.storeName, 70, yPos)
  yPos += 8

  doc.setFont('helvetica', 'normal')
  doc.text('Alamat Pengerjaan:', 20, yPos)
  doc.setFont('helvetica', 'bold')
  const workAddressLines = doc.splitTextToSize(bastData.workAddress, 120)
  doc.text(workAddressLines, 70, yPos)
  yPos += workAddressLines.length * 7 + 5

  doc.setFont('helvetica', 'normal')
  doc.text('Nama PIC IT:', 20, yPos)
  doc.setFont('helvetica', 'bold')
  doc.text(bastData.picName, 70, yPos)
  yPos += 8

  doc.setFont('helvetica', 'normal')
  doc.text('Nomor PO:', 20, yPos)
  doc.setFont('helvetica', 'bold')
  doc.text(bastData.poNumber, 70, yPos)
  yPos += 8

  doc.setFont('helvetica', 'normal')
  doc.text('Tanggal Selesai Pengerjaan:', 20, yPos)
  doc.setFont('helvetica', 'bold')
  const completionDate = new Date(bastData.completionDate).toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  })
  doc.text(completionDate, 70, yPos)
  yPos += 15

  // Section: Informasi Tambahan
  if (bastData.additionalFields && bastData.additionalFields.length > 0) {
    doc.setFontSize(14)
    doc.setFont('helvetica', 'bold')
    doc.text('IV. INFORMASI TAMBAHAN', 20, yPos)
    yPos += 10

    doc.setFontSize(11)
    doc.setFont('helvetica', 'normal')

    bastData.additionalFields.forEach((field) => {
      if (field.key && field.value) {
        doc.text(`${field.key}:`, 20, yPos)
        doc.setFont('helvetica', 'bold')
        doc.text(field.value, 70, yPos)
        doc.setFont('helvetica', 'normal')
        yPos += 8
      }
    })
    yPos += 7
  }

  // Signature Section
  if (yPos > 220) {
    doc.addPage()
    yPos = 20
  }

  yPos += 10
  doc.setFontSize(14)
  doc.setFont('helvetica', 'bold')
  doc.text('V. PERNYATAAN', 20, yPos)
  yPos += 15

  doc.setFontSize(11)
  doc.setFont('helvetica', 'normal')
  const statement = 'Dengan ini kami menyatakan bahwa pekerjaan telah selesai dilaksanakan sesuai dengan spesifikasi yang disepakati.'
  const statementLines = doc.splitTextToSize(statement, 170)
  doc.text(statementLines, 20, yPos)
  yPos += statementLines.length * 7 + 15

  // Signature columns
  const vendorX = 30
  const itX = 120
  const signatureY = yPos + 30

  // Vendor Signature
  doc.setFontSize(11)
  doc.setFont('helvetica', 'bold')
  doc.text('Vendor', vendorX + 15, signatureY, { align: 'center' })
  yPos += 5
  doc.setFont('helvetica', 'normal')
  doc.text('(................................)', vendorX + 15, signatureY + 30, { align: 'center' })

  // IT Signature
  doc.setFont('helvetica', 'bold')
  doc.text('IT Department', itX + 15, signatureY, { align: 'center' })
  doc.setFont('helvetica', 'normal')
  doc.text('(................................)', itX + 15, signatureY + 30, { align: 'center' })

  // Footer
  const pageCount = doc.getNumberOfPages()
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i)
    doc.setFontSize(9)
    doc.setFont('helvetica', 'normal')
    doc.text(
      `Dokumen ini dihasilkan secara otomatis oleh Sistem BAST Kedai Kopi - Hal ${i} dari ${pageCount}`,
      105,
      285,
      { align: 'center' }
    )
  }

  return Buffer.from(doc.output('arraybuffer'))
}
