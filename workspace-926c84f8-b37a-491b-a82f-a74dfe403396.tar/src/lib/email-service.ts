import nodemailer from 'nodemailer'
import { generateBASTPDF } from '@/lib/utils/pdf-generator'

// Email configuration - in production, use environment variables
const transporter = nodemailer.createTransporter({
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: process.env.SMTP_SECURE === 'true',
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS
  }
})

export interface EmailRecipient {
  name: string
  email: string
}

export interface BASTEmailData {
  bastNumber: string
  submitterName: string
  companyName: string
  installationType: string
  storeName: string
  poNumber: string
  completionDate: string
  vendorEmail: string
  additionalFields: { key: string; value: string }[]
  createdAt: string
}

// Send BAST to IT Support with approve/reject buttons
export async function sendBASTToITSupport(
  bastData: BASTEmailData,
  itSupportEmail: string,
  itSupportName: string
): Promise<void> {
  try {
    const pdfBuffer = generateBASTPDF(bastData)

    // Get the base URL from environment or use default
    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'

    const approveUrl = `${baseUrl}/approve`
    const trackUrl = `${baseUrl}/?track=${bastData.bastNumber}`

    const mailOptions = {
      from: process.env.SMTP_FROM || '"Sistem BAST Kedai Kopi" <no-reply@kedai-kopi.com>',
      to: itSupportEmail,
      subject: `Approval BAST Required - ${bastData.bastNumber}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #ea580c; margin-bottom: 20px;">Permintaan Approval BAST Baru</h2>

          <p>Halo <strong>${itSupportName}</strong>,</p>

          <p>Terdapat pengajuan BAST baru yang membutuhkan approval Anda:</p>

          <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin: 20px 0;">
            <table style="width: 100%;">
              <tr>
                <td style="padding: 5px;"><strong>No BAST:</strong></td>
                <td style="padding: 5px;">${bastData.bastNumber}</td>
              </tr>
              <tr>
                <td style="padding: 5px;"><strong>Nama Perusahaan:</strong></td>
                <td style="padding: 5px;">${bastData.companyName}</td>
              </tr>
              <tr>
                <td style="padding: 5px;"><strong>Jenis Instalasi:</strong></td>
                <td style="padding: 5px;">${bastData.installationType}</td>
              </tr>
              <tr>
                <td style="padding: 5px;"><strong>Nama Store:</strong></td>
                <td style="padding: 5px;">${bastData.storeName}</td>
              </tr>
              <tr>
                <td style="padding: 5px;"><strong>Nomor PO:</strong></td>
                <td style="padding: 5px;">${bastData.poNumber}</td>
              </tr>
              <tr>
                <td style="padding: 5px;"><strong>Tanggal Selesai:</strong></td>
                <td style="padding: 5px;">${bastData.completionDate}</td>
              </tr>
              <tr>
                <td style="padding: 5px;"><strong>Email Vendor:</strong></td>
                <td style="padding: 5px;">${bastData.vendorEmail}</td>
              </tr>
            </table>
          </div>

          <p>Dokumen PDF BAST terlampir untuk review Anda.</p>

          <h3 style="margin-top: 30px;">Aksi Approval:</h3>
          <p>Silakan klik salah satu tombol di bawah ini:</p>

          <div style="margin: 20px 0; text-align: center;">
            <a href="${approveUrl}?bastNumber=${bastData.bastNumber}&role=it_support&action=approve"
               style="background-color: #22c55e; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block; margin-right: 10px; font-weight: bold;">
              ✓ Approve
            </a>
            <a href="${approveUrl}?bastNumber=${bastData.bastNumber}&role=it_support&action=reject"
               style="background-color: #ef4444; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block; font-weight: bold;">
              ✗ Reject
            </a>
          </div>

          <p style="margin-top: 30px; font-size: 12px; color: #666;">
            Atau lacak status BAST di: <a href="${trackUrl}">${trackUrl}</a>
          </p>

          <hr style="margin: 30px 0; border: none; border-top: 1px solid #ddd;">

          <p style="font-size: 12px; color: #666;">
            Email ini dikirim otomatis oleh Sistem BAST Kedai Kopi.<br>
            Jangan membalas email ini.
          </p>
        </div>
      `,
      attachments: [
        {
          filename: `BAST_${bastData.bastNumber}.pdf`,
          content: pdfBuffer,
          contentType: 'application/pdf'
        }
      ]
    }

    await transporter.sendMail(mailOptions)
    console.log(`Email sent to IT Support: ${itSupportEmail}`)
  } catch (error) {
    console.error('Error sending email to IT Support:', error)
    throw error
  }
}

// Send BAST to IT Manager with approve/reject buttons
export async function sendBASTToITManager(
  bastData: BASTEmailData,
  itManagerEmail: string,
  itManagerName: string
): Promise<void> {
  try {
    const pdfBuffer = generateBASTPDF(bastData)

    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'

    const approveUrl = `${baseUrl}/approve`
    const trackUrl = `${baseUrl}/?track=${bastData.bastNumber}`

    const mailOptions = {
      from: process.env.SMTP_FROM || '"Sistem BAST Kedai Kopi" <no-reply@kedai-kopi.com>',
      to: itManagerEmail,
      subject: `Approval BAST Required - ${bastData.bastNumber}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #ea580c; margin-bottom: 20px;">Approval BAST - IT Manager</h2>

          <p>Halo <strong>${itManagerName}</strong>,</p>

          <p>Berikut adalah BAST yang telah disetujui oleh IT Support dan membutuhkan approval Anda:</p>

          <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin: 20px 0;">
            <table style="width: 100%;">
              <tr>
                <td style="padding: 5px;"><strong>No BAST:</strong></td>
                <td style="padding: 5px;">${bastData.bastNumber}</td>
              </tr>
              <tr>
                <td style="padding: 5px;"><strong>Nama Perusahaan:</strong></td>
                <td style="padding: 5px;">${bastData.companyName}</td>
              </tr>
              <tr>
                <td style="padding: 5px;"><strong>Jenis Instalasi:</strong></td>
                <td style="padding: 5px;">${bastData.installationType}</td>
              </tr>
              <tr>
                <td style="padding: 5px;"><strong>Nama Store:</strong></td>
                <td style="padding: 5px;">${bastData.storeName}</td>
              </tr>
              <tr>
                <td style="padding: 5px;"><strong>Nomor PO:</strong></td>
                <td style="padding: 5px;">${bastData.poNumber}</td>
              </tr>
              <tr>
                <td style="padding: 5px;"><strong>Tanggal Selesai:</strong></td>
                <td style="padding: 5px;">${bastData.completionDate}</td>
              </tr>
              <tr>
                <td style="padding: 5px;"><strong>Email Vendor:</strong></td>
                <td style="padding: 5px;">${bastData.vendorEmail}</td>
              </tr>
            </table>
          </div>

          <p>Dokumen PDF BAST terlampir untuk review Anda.</p>

          <h3 style="margin-top: 30px;">Aksi Approval:</h3>
          <p>Silakan klik salah satu tombol di bawah ini:</p>

          <div style="margin: 20px 0; text-align: center;">
            <a href="${approveUrl}?bastNumber=${bastData.bastNumber}&role=it_manager&action=approve"
               style="background-color: #22c55e; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block; margin-right: 10px; font-weight: bold;">
              ✓ Approve
            </a>
            <a href="${approveUrl}?bastNumber=${bastData.bastNumber}&role=it_manager&action=reject"
               style="background-color: #ef4444; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block; font-weight: bold;">
              ✗ Reject
            </a>
          </div>

          <p style="margin-top: 30px; font-size: 12px; color: #666;">
            Atau lacak status BAST di: <a href="${trackUrl}">${trackUrl}</a>
          </p>

          <hr style="margin: 30px 0; border: none; border-top: 1px solid #ddd;">

          <p style="font-size: 12px; color: #666;">
            Email ini dikirim otomatis oleh Sistem BAST Kedai Kopi.<br>
            Jangan membalas email ini.
          </p>
        </div>
      `,
      attachments: [
        {
          filename: `BAST_${bastData.bastNumber}.pdf`,
          content: pdfBuffer,
          contentType: 'application/pdf'
        }
      ]
    }

    await transporter.sendMail(mailOptions)
    console.log(`Email sent to IT Manager: ${itManagerEmail}`)
  } catch (error) {
    console.error('Error sending email to IT Manager:', error)
    throw error
  }
}

// Send approval notification to vendor
export async function sendApprovalNotificationToVendor(
  bastData: BASTEmailData,
  status: 'approved' | 'rejected'
): Promise<void> {
  try {
    const pdfBuffer = generateBASTPDF(bastData)

    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'
    const trackUrl = `${baseUrl}/?track=${bastData.bastNumber}`

    const isApproved = status === 'approved'
    const subject = isApproved
      ? `BAST Disetujui - ${bastData.bastNumber}`
      : `BAST Ditolak - ${bastData.bastNumber}`
    const headerColor = isApproved ? '#22c55e' : '#ef4444'
    const statusText = isApproved ? 'Disetujui' : 'Ditolak'
    const statusIcon = isApproved ? '✓' : '✗'

    const mailOptions = {
      from: process.env.SMTP_FROM || '"Sistem BAST Kedai Kopi" <no-reply@kedai-kopi.com>',
      to: bastData.vendorEmail,
      subject: subject,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: ${headerColor}; margin-bottom: 20px;">BAST ${statusText} - ${statusIcon}</h2>

          <p>Halo <strong>${bastData.submitterName}</strong>,</p>

          <p>Berikut adalah status pengajuan BAST Anda:</p>

          <div style="background-color: ${isApproved ? '#dcfce7' : '#fee2e2'}; padding: 15px; border-radius: 5px; margin: 20px 0;">
            <table style="width: 100%;">
              <tr>
                <td style="padding: 5px;"><strong>No BAST:</strong></td>
                <td style="padding: 5px;">${bastData.bastNumber}</td>
              </tr>
              <tr>
                <td style="padding: 5px;"><strong>Status:</strong></td>
                <td style="padding: 5px;"><strong>${statusText}</strong></td>
              </tr>
              <tr>
                <td style="padding: 5px;"><strong>Jenis Instalasi:</strong></td>
                <td style="padding: 5px;">${bastData.installationType}</td>
              </tr>
              <tr>
                <td style="padding: 5px;"><strong>Nama Store:</strong></td>
                <td style="padding: 5px;">${bastData.storeName}</td>
              </tr>
            </table>
          </div>

          ${isApproved ? `
            <p>Selamat! BAST Anda telah disetujui oleh IT Support dan IT Manager.</p>
            <p>Dokumen PDF BAST terlampir untuk keperluan administrasi Anda.</p>
          ` : `
            <p>Mohon maaf, BAST Anda tidak disetujui. Silakan hubungi IT Support untuk informasi lebih lanjut.</p>
          `}

          <p style="margin-top: 30px; font-size: 12px; color: #666;">
            Lacak status BAST di: <a href="${trackUrl}">${trackUrl}</a>
          </p>

          <hr style="margin: 30px 0; border: none; border-top: 1px solid #ddd;">

          <p style="font-size: 12px; color: #666;">
            Email ini dikirim otomatis oleh Sistem BAST Kedai Kopi.<br>
            Jangan membalas email ini.
          </p>
        </div>
      `,
      attachments: [
        {
          filename: `BAST_${bastData.bastNumber}.pdf`,
          content: pdfBuffer,
          contentType: 'application/pdf'
        }
      ]
    }

    await transporter.sendMail(mailOptions)
    console.log(`Email sent to vendor: ${bastData.vendorEmail}`)
  } catch (error) {
    console.error('Error sending email to vendor:', error)
    throw error
  }
}

// Send rejection notification
export async function sendRejectionNotification(
  email: string,
  name: string,
  bastNumber: string,
  reason: string
): Promise<void> {
  try {
    const mailOptions = {
      from: process.env.SMTP_FROM || '"Sistem BAST Kedai Kopi" <no-reply@kedai-kopi.com>',
      to: email,
      subject: `BAST Ditolak - ${bastNumber}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #ef4444; margin-bottom: 20px;">BAST Ditolak</h2>

          <p>Halo <strong>${name}</strong>,</p>

          <p>Berikut adalah status pengajuan BAST Anda:</p>

          <div style="background-color: #fee2e2; padding: 15px; border-radius: 5px; margin: 20px 0;">
            <p><strong>No BAST:</strong> ${bastNumber}</p>
            <p><strong>Status:</strong> <strong>Ditolak</strong></p>
          </div>

          <p>Alasan penolakan:</p>
          <p style="background-color: #f5f5f5; padding: 10px; border-radius: 5px;">${reason}</p>

          <p>Mohon perbaiki dan submit ulang BAST Anda jika diperlukan.</p>

          <hr style="margin: 30px 0; border: none; border-top: 1px solid #ddd;">

          <p style="font-size: 12px; color: #666;">
            Email ini dikirim otomatis oleh Sistem BAST Kedai Kopi.<br>
            Jangan membalas email ini.
          </p>
        </div>
      `
    }

    await transporter.sendMail(mailOptions)
    console.log(`Rejection notification sent to: ${email}`)
  } catch (error) {
    console.error('Error sending rejection notification:', error)
    throw error
  }
}
